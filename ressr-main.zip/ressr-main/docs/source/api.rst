API Documentation
=================

Primary module:

..
    Note:  add other modules and descriptions as needed.

* ResSR_ ResSR is an efficient and modular residual-based method for super-resolving the lower-resolution bands of a multispectral image.

.. _ResSR: ResSR.html
.. toctree::
   :titlesonly:
   :hidden:

   ResSR
