ResSR
--------------------------

..
    Adjust the dashes above to match the number of characters in ResSR
    Include functions names as a comma separated list under :members below and one per line under autosummary below.

.. automodule:: ResSR
    :members:
    :undoc-members:
    :show-inheritance:

    .. rubric:: **Functions:**

    .. autosummary::





