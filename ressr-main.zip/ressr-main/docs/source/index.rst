.. ResSR documentation master file, created by
   sphinx-quickstart on Fri Jun 25 14:24:26 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`



.. toctree::
   :hidden:
   :maxdepth: 4
   :caption: User Guide

   install
   api

.. toctree::
   :hidden:
   :maxdepth: 4
   :caption: Developer Guide

   docs