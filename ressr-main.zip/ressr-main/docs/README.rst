.. include:: ../../README.rst
  :start-after: docs-include-ref

System Requirements
-------------------
1. Python>=3.9.19


Optional System Requirements
----------------------------
We also recommend:

* Installation using conda environment

License
-------
The project is licensed under the `BSD 3-Clause <https://opensource.org/license/BSD-3-clause/>`_ License.


